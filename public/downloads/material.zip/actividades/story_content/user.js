function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6MIEnQK6yax":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

