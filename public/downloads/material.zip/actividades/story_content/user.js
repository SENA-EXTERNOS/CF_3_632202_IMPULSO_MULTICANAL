function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5w7u0eSVh9b":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

